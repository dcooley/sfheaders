context("sfx_explode")
# v432_AP
data(emisco)
a <- sfx_explode(emisco)

