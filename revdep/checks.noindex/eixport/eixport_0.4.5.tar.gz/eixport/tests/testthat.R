library(testthat)
library(eixport)

test_check("eixport")
