#' Raw profile
#'
#' Raw profile
#'
#' @format A matrix with 1 column and 168 rows
#' \describe{
#'   data(rawprofile)
#' }
#' @usage data(rawprofile)
#' @docType data
"rawprofile"
