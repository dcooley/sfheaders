#ifndef R_SPATIALWIDGET_BINARY_H
#define R_SPATIALWIDGET_BINARY_H

namespace spatialwidget {
namespace binary {

  inline Rcpp::StringVector to_binary() {
  }

} // binary
} // spatialwidget

#endif
