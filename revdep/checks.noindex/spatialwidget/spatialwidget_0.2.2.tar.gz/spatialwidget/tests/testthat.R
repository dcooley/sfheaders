library(testthat)
library(spatialwidget)

test_check("spatialwidget")
